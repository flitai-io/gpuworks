# SPDX-License-Identifier: Apache-2.0
"""Run cancellation checks at step boundaries even when tqdm is disabled."""

from collections.abc import Callable
from typing import Any

from tqdm.auto import tqdm


class CancelAwareTqdm(tqdm):
    def __init__(self, *args: Any, on_step: Callable[[], None], **kwargs: Any):
        super().__init__(*args, **kwargs)
        self._on_step = on_step
        self._iterating = False

    def update(self, n: float | None = 1) -> bool | None:
        displayed = super().update(n)
        if not self._iterating and n is not None and n > 0:
            self._on_step()
        return displayed

    def __iter__(self):
        self._iterating = True
        try:
            for obj in super().__iter__():
                yield obj
                self._on_step()
        finally:
            self._iterating = False
